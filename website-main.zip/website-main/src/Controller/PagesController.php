<?php

namespace App\Controller;

use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\AbstractType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Http\Authentication\AuthenticationUtils;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\TelType;

use Symfony\Component\HttpFoundation\Request;
use App\Entity\Event;


class PagesController extends AbstractController
{
    /**
     * @Route("/", name="frontpage")
     */
    public function index(): Response
    {
        return $this->render('frontpage.html.twig', [
            'title' => 'Welcome!',
            'navlinks' => $this->navLinks(),
        ]);
    }

    /**
     * @Route("/login", name="login")
     */
    public function login(AuthenticationUtils $authenticationUtils): Response
    {
       // get the login error if there is one
       $error = $authenticationUtils->getLastAuthenticationError();

       // last username entered by the user
       $lastUsername = $authenticationUtils->getLastUsername();

        return $this->render('login/index.html.twig', [
           'last_username' => $lastUsername,
           'error'         => $error,
           'title'         => "Log In",
           'navlinks' => $this->navLinks(),
      ]);
  }

    /**
     * @Route("/logout", name="app_logout", methods={"GET"})
     */
    public function logout(): void
    {
        // controller can be blank: it will never be called!
        throw new \Exception('Don\'t forget to activate logout in security.yaml');
    }

    /**
     * Display the donor page.
     *
     * @Route("/donations", name="donationpage")
     */
    public function donations(): Response
    {
        return $this->render('donorpage.html.twig', [
            'title' => 'Donations!',
            'navlinks' => $this->navLinks(),
        ]);
    }

    /**
     * Display the crisis page.
     *
     * @Route("/crisis", name="crisispage")
     */
    public function Crisis(): Response
    {
        return $this->render('crisispage.html.twig', [
            'title' => 'Crisis Links!',
            'navlinks' => $this->navLinks(),
        ]);
    }

    /**
     * Display the about us page.
     *
     * @Route("/about", name="aboutuspage")
     */
    public function about(): Response
    {
        return $this->render('aboutuspage.html.twig', [
            'title' => 'About us',
            'navlinks' => $this->navLinks(),
        ]);
    }


    /**
     * Method for displaying events page.
     *
     * @Route("/events", name="eventspage")
     */
    public function events(): Response
    {
        $events = $this->getDoctrine()->getRepository(Event::class)->findUpComing();

        return $this->render('eventspage.html.twig', [
            'title' => 'Welcome!',
            'navlinks' => $this->navLinks(),
            'events' => $events,
        ]);
    }


    /**
     * Method for displaying contact us page.
     *
     * @Route("/contact", name="contactuspage")
     */
    public function contactus(Request $request): Response
    {
        // Form builder (Adds form and form tags in php)
        $form = $this->createFormBuilder([])
            ->add('contactName', TextType::class, ['label' => 'Name', 'required' => true])
            ->add('contactEmail', EmailType::class, ['label' => 'Email', 'required' => true])
            ->add('contactMessageBox', TextareaType::class, ['label' => 'Type your message below', 'required' => true])
            ->add('submit', SubmitType::class)
            ->getForm();

        // gets form request
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

            $results = $form->getData(); //holds the submitted values

            dump($form); // dumps for now so backend can work on it
        }

        return $this->render('contactuspage.html.twig', [
            'title' => 'Contact us!',
            'navlinks' => $this->navLinks(),
            'form' => $form->createView(),
        ]);
    }


    /**
     * Method for displaying volunteer page.
     *
     * @Route("/volunteer", name="volunteerpage")
     */
    public function volunteer(Request $request): Response
    {
        // form builder
        $form = $this->createFormBuilder([])
            ->add('volName', TextType::class, ['label' => 'Name', 'required' => true])
            ->add('volEmail', EmailType::class, ['label' => 'Email', 'required' => true])
            ->add('volTelType', TelType::class, ['label' => 'Phone Number', 'required' => true])
            ->add('submit', SubmitType::class)
            ->getForm();

        // gets form request
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

            $results = $form->getData(); //holds the submitted values

            dump($form); // dumps for now so backend can work on it
        }

        return $this->render('volunteerpage.html.twig', [
            'title' => 'Volunteer',
            'navlinks' => $this->navLinks(),
            'form' => $form->createView(),
        ]);
    }

    /**
     * form dump
     *
     * @Route("/Dump", name="formdump")
     */
    public function dump($form): void
    {
        // just a method that does nothing so backend can work on this
        // NOTE: feel free to get rid of this method and change the call
        //       so that way this isnt taking up space
    }

    /**
     * This provides navigation links.
     *
     * @todo Replace this with actual dynamic content.
     */
    private function navLinks(): string {
        return '
            <a href="' . $this->generateUrl('frontpage') . '">Home</a>
            <a href="' . $this->generateUrl('eventspage') . '">Events</a>
            <a href="' . $this->generateUrl('donationpage') . '">Donors</a>
            <a href="' . $this->generateUrl('volunteerpage') . '">Volunteer</a>
            <a href="' . $this->generateUrl('crisispage') . '">Crisis Links</a>
            <a href="' . $this->generateUrl('contactuspage') . '">Contact Us</a>
            <a href="' . $this->generateUrl('aboutuspage') . '">About Us</a>
        ';
    }

}
