<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManagerInterface;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use App\Entity\Person;
use App\Entity\Event;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;
use App\Repository\PersonRepository;
use App\Repository\EventRepository;

class RestApiController extends AbstractController
{
    /**
     * checkAuthorization method verifies the JWT token is valid.
     */
    private function checkAuthorization(Request $request)
    {
        $key = $_ENV['JWT_SECRET'];
        $authorization = $request->headers->get('Authorization');

        // Checks for a token
        if(empty($authorization)){
            return [
                'message' => 'error',
                'error' => 'missing authorization',
            ];
        };

        $authorization = preg_replace('/^Bearer /', '', $authorization);

        // Checks if token is valid, then returns user information
        try{
           $token = JWT::decode($authorization, $key, ['HS256']);
           $user = $this->getDoctrine()->getRepository(Person::class)->find($token->sub);

           return ['user' => $user];

        }
        catch (\Exception $e) {

            return [
                'message' => 'error',
                'error' => $e->getMessage(),
            ];
        }
    }

    /**
     * Api test method will be an example of future methods.
     *
     * @Route("/api/test", name="api_test")
     */
    public function apiTest(Request $request): Response
    {
        // Call the checkAuthorization method.
        $authorization = $this->checkAuthorization($request);

        // if token isn't excepted, this will give you an token error message
        if (!empty($authorization['error'])){
            return $this->json($authorization);
        }
        // user data pulled from database
        $user = $authorization['user'];


        if ($payload = $request->getContent()) {
            $payload = json_decode($payload);
            $response = [
                'message' => 'ok',
                'data' => [
                    'request' => $payload,
                    'roles' => $user->getRoles(),
                    'person' => $user->getUsername(),
                ],
            ];
        }
        else {
            $response = [
                'message' => 'error',
                'error' => 'payload not found',
            ];
        }

        return $this->json($response);
    }

     /**
     * API LOGIN.
     *
     * @Route("/api/login", name="api_login")
     */
    public function apiLogin()
    {
        $user = $this->getUser() ?? NULL;
        $key = $_ENV['JWT_SECRET'];
        $payload = array(
            "sub" => $user->getId(),
            "iat" => time(),
            "exp" => time()+3600,
        );

        $jwt = JWT::encode($payload, $key, 'HS256');

        return $this->json([
            'message' => 'login successful',
            'user' => $user->getUserIdentifier(),
            'roles' => $user->getRoles(),
            'token' => $jwt,
        ]);
    }

    ############################## Persons ##############################

    /**
     * @Route("/api/people", name="api_people")
     */
    public function getPeople(Request $request): Response
    {
        // Call the checkAuthorization method.
        $authorization = $this->checkAuthorization($request);

        // if token isn't excepted, this will give you an token error message
        if (!empty($authorization['error'])){
            return $this->json($authorization);
        }

        $people = $this->getDoctrine()->getRepository(Person::class)->findAll();
        $arrayCollection = array();

        foreach($people as $item)
        {
            $arrayCollection[$item->getId()] = $item->toArray();
        }
        return $this->json($arrayCollection);
    }

    /**
     * @Route("/api/addperson", name="api_addPerson")
     */
    public function addPerson(UserPasswordHasherInterface $passwordHasher, Request $request): Response
    {
        // Call the checkAuthorization method.
        $authorization = $this->checkAuthorization($request);

        // if token isn't excepted, this will give you an token error message
        if (!empty($authorization['error'])){
            return $this->json($authorization);
        }

        $entityManager = $this->getDoctrine()->getManager();

        if ($payload = $request->getContent())
        {
            $payload = json_decode($payload, true);
            $fields = array(
                'person_email',
                'person_first_name',
                'person_last_name',
                'password'
            );
            $missing_fields = [];

            foreach ($fields as $fieldname) {
                if (empty($payload[$fieldname])){
                    $missing_fields[] = $fieldname;
                }
            }

            if(!empty($missing_fields)) {
                $missing = implode(', ',$missing_fields);

                return $this->json([
                    'error' => "Required field(s) $missing not set while adding user.",
                ]);
            }

            $person = new Person();
            $password = $payload["password"];
            $hashedPassword = $passwordHasher->hashPassword($person,$password);
            $arrayCollection = array();

            $person->setPersonEmail($payload["person_email"]);
            $person->setPersonFirstName($payload["person_first_name"]);
            $person->setPersonLastName($payload["person_last_name"]);
            $person->setRoles($payload["roles"] ?? ['ROLE_USER']);
            $person->setPersonPhoneNumber($payload["person_phone_number"] ?? NULL);
            $person->setPassword($hashedPassword);

            $entityManager->persist($person);

            $entityManager->flush();

            return $this->json([
                'message' => 'person creation successful',
                'person' => $person->toArray(),
            ]);
        }
    }

    /**
     * @Route("/api/person/{id}/update", name="api_updatePerson")
     */
    public function updatePerson(UserPasswordHasherInterface $passwordHasher, Request $request, int $id): Response
    {
        // Call the checkAuthorization method.
        $authorization = $this->checkAuthorization($request);

        // if token isn't excepted, this will give you an token error message
        if (!empty($authorization['error'])){
            return $this->json($authorization);
        }

        $payload = $request->getContent();
        $payload = json_decode($payload, true);

        $person = $this->getDoctrine()->getRepository(Person::class)->find($id);
        $entityManager = $this->getDoctrine()->getManager();

        if (!$person) {
            return new Response('No person found for id '.$id);
        }

        if (isset($payload['person_email'] )) {
            if (empty(trim(($payload['person_email'])))){

                return $this->json([
                'error' => 'Error: Field person_email cant be left empty',
            ]);
        }
            $person->setPersonEmail($payload["person_email"]);
        }

        if (isset($payload["roles"])) {

            $roles = $payload["roles"];

            foreach ($roles as $item)
            {
                if (empty(trim($item))){
                    return $this->json([
                    'error' => 'Error: Field roles cant be left empty',
                ]);
            }
            else
            {
                $roles[] = $item;
            }
            }
            $person->setRoles($payload["roles"]);
        }

        if (isset($payload['password'] )) {
            if (empty(trim(($payload['password'])))){

                return $this->json([
                'error' => 'Error: Field password cant be left empty',
            ]);
        }
            $password = $payload["password"];
            $hashedPassword = $passwordHasher->hashPassword($person,$password);
            $person->setPassword($hashedPassword);
        }

        if (isset($payload['person_first_name'] )){
            if (empty(trim(($payload['person_first_name'])))){

                return $this->json([
                'error' => 'Error: Field person_first_name cant be left empty',
            ]);
        }
            $person->setPersonFirstName($payload["person_first_name"]);
        }

        if (isset($payload['person_last_name'] ))
        {
            if (empty(trim(($payload['person_last_name'])))){

                return $this->json([
                'error' => 'Error: Field person_last_name cant be left empty',
            ]);
        }
            $person->setPersonLastName ($payload["person_last_name"]);
        }

        if (isset($payload['person_phone_number'] ))
        {
            if (empty(trim(($payload['person_phone_number'])))){

                return $this->json([
                'error' => 'Error: Field person_phone_number cant be left empty',
            ]);
        }
            $person->setPersonPhoneNumber($payload["person_phone_number"]);
        }

        $entityManager->persist($person);
        $entityManager->flush();

        return $this->json([
            'message' => 'Person Updated successful!',
            'person' => $person->toArray(),
        ]);
    }

    ############################## Events ##############################

    /**
     * @Route("/api/events", name="api_events")
     */
    public function getEvent(Request $request): Response
    {
        // Call the checkAuthorization method.
        $authorization = $this->checkAuthorization($request);

        // if token isn't excepted, this will give you an token error message
        if (!empty($authorization['error'])){
            return $this->json($authorization);
        }
        $event = $this->getDoctrine()->getRepository(Event::class)->findAll();
        $arrayCollection = array();

        foreach($event as $item)
        {
            $arrayCollection[$item->getId()] = $item->toArray();
        }
        return $this->json($arrayCollection);
    }

    /**
     * @Route("/api/addevent", name ="api_addEvent")
     */
    public function addEvent(Request $request): Response
    {
        // Call the checkAuthorization method.
        $authorization = $this->checkAuthorization($request);

        // if token isn't excepted, this will give you an token error message
        if (!empty($authorization['error'])){
            return $this->json($authorization);
        }
        //Connet to the Database
        $entityManager = $this->getDoctrine()->getManager();

        if ($payload = $request->getContent())
        {
            //---The JSON string beeing Decoded. Because we will use an aray, set to true-----//
            $payload = json_decode($payload, true);

            $elements = array(
                    'event_name',
                    'event_location',
                    'event_time',
                    'event_date',
                    'event_description'
            );
            $required_elemnts =[];
            //--We will store the fieled Name of the missing fieled in this array Using the f.oreach f.unction--//

            foreach($elements as $elementName){

                if (empty($payload[$elementName]))
                    {
                        $required_elemnts[] = $elementName;
                    }
                    //--Now the-required_elemnts- array contains the Names of the Missing fieleds--//
            }
            //--This Desision statment will detect the elemnts of the array that contain data in them. Note: The data is names of the missing fieldes--//
            if(!empty($required_elemnts)){

                $required = implode( ', ',$required_elemnts);
                //--This will add a (,) between every elemnt of the array and set it as a string--//

                return $this->json([
                    'error' => "Required field(s) $required missing while adding Event.",
                ]);
            }
            //Now we actualy create a new Event///
            $event = new Event();
            $time = $payload["event_time"];
            $date = $payload["event_date"];
            $dateTime = \DateTime::createFromFormat("m/d/Y H:i:s", "$date $time");

            $event->setEventName($payload["event_name"]);
            $event->setEventLocation($payload["event_location"]);
            $event->setEventTime($dateTime);
            $event->setEventDate($dateTime);
            $event->setEventDescription($payload["event_description"]);



            $entityManager->persist($event); //--The EntityManager->persist() is used to register an entity the database.--//

            $entityManager->flush(); //-- EntityManager.flush() actually runs the query on your database--//

            return $this->json([
                'message' => 'Event creation successful!',
                'event' => $event->toArray()
            ]);

        }
    }

    /**
     * @Route("/api/event/{id}/update", name="api_updateEvent")
     */
    public function updateEvent(Request $request, int $id): Response
    {
        // Call the checkAuthorization method.
        $authorization = $this->checkAuthorization($request);

        // if token isn't excepted, this will give you an token error message
        if (!empty($authorization['error'])){
            return $this->json($authorization);
        }
        $payload = $request->getContent();
        $payload = json_decode($payload, true);

        //Connet to the Database
        $event = $this->getDoctrine()->getRepository(Event::class)->find($id);

        $entityManager = $this->getDoctrine()->getManager();

        if (!$event) {

            return $this->json([
                'error' => 'Error: No Event found for id '.$id,
                ]);
        }


        if (isset($payload['event_date']) && isset($payload['event_time']) ){
            if (empty(trim(($payload['event_date'])))){

                return $this->json([
                'error' => 'Error: Field event_name cant be left empty',
                ]);
            }

            if (empty(trim(($payload['event_time'])))){

                return $this->json([
                'error' => 'Error: Field event_time cant be left empty',
                ]);
            }

            $date = $payload["event_date"];
            $time = $payload["event_time"];
            $dateTime = \DateTime::createFromFormat("m/d/Y H:i:s", "$date $time");


            $event->setEventTime($dateTime);
            $event->setEventDate($dateTime);
        }

        elseif(isset($payload['event_date'])){
                 return $this->json([
                'error' => 'Error: Must select both Data and time, Missing Time ',
                ]);
            }
        elseif(isset($payload['event_time'])){
                return $this->json([
                'error' => 'Error: Must select both Data and time, Missing Date ',
                ]);
            }

        if (isset($payload['event_location'] )) {
            if (empty(trim(($payload['event_location'])))){

                return $this->json([
                'error' => 'Error: Field event_location cant be left empty',
            ]);
        }
            $event->setEventLocation($payload["event_location"]);
        }

        if (isset($payload['event_name'] )) {
            if (empty(trim(($payload['event_name'])))){

                return $this->json([
                'error' => 'Error: Field event_name cant be left empty',
            ]);
            }
            $event->setEventName($payload["event_name"]);
        }

        if (isset($payload['event_description'])) {
            if (empty(trim(($payload['event_description'])))){

                return $this->json([
                'error' => 'Error: Field event_description cant be left empty',
            ]);
            }
            $event->setEventDescription($payload["event_description"]);
        }

        $entityManager->flush();


        return $this->json([
                'message' => 'Event Update successful!',
                'event' => $event->toArray()
            ]);
    }

    ############################## Person_Event ##############################


    /**
     * @Route("/api/person/{person_id}/event/{event_id}/add", name="api_personevent_add")
     */
     public function addPersonEvent(Request $request, int $person_id, int $event_id)
     {
          // Call the checkAuthorization method.
        $authorization = $this->checkAuthorization($request);

        // if token isn't excepted, this will give you an token error message
        if (!empty($authorization['error'])){
            return $this->json($authorization);
        }

        $entityManager = $this->getDoctrine()->getManager();

        //Connect to the Database
        $event = $this->getDoctrine()->getRepository(Event::class)->find($event_id);
        $person = $this->getDoctrine()->getRepository(Person::class)->find($person_id);

        if (!$event) {

            return $this->json([
                'error' => 'Error: No Event found for id '.$event_id,
                ]);
        }

        if(!$person)
        {

            return $this->json([
                'error' => 'Error: No Person found for id '.$person_id,
                ]);
        }

        $event->addPerson($person);

        $entityManager->persist($person);
        $entityManager->flush();

        return $this->json([
            'message' => 'Person Event association made',
            'person' => $person->toArray(),
            'event' => $event->toArray()
        ]);
    }

    /**
     * @Route("/api/person/{person_id}/event/{event_id}/remove", name="api_personevent_remove")
     */
    public function removePersonEvent(Request $request, int $person_id, int $event_id)
    {
        // Call the checkAuthorization method.
        $authorization = $this->checkAuthorization($request);

        // if token isn't excepted, this will give you an token error message
        if (!empty($authorization['error'])){
            return $this->json($authorization);
        }

        $entityManager = $this->getDoctrine()->getManager();

        //Connect to the Database
        $event = $this->getDoctrine()->getRepository(Event::class)->find($event_id);
        $person = $this->getDoctrine()->getRepository(Person::class)->find($person_id);

        if (!$event) {

            return $this->json([
                'error' => 'Error: No Event found for id '.$event_id,
                ]);
        }

        if(!$person)
        {

            return $this->json([
                'error' => 'Error: No Person found for id '.$person_id,
                ]);
        }

        $person->removeEvent($event);

        $entityManager->persist($person);
        $entityManager->flush();

        return $this->json([
            'message' => 'Person Event association removed',
            'person' => $person->toArray()
        ]);
    }

    /**
     * @Route("/api/person/{person_id}/events", name="api_getpersonevents")
     */
    public function getPersonEvents(Request $request, int $person_id)
    {
        // Call the checkAuthorization method.
        $authorization = $this->checkAuthorization($request);

        // if token isn't excepted, this will give you an token error message
        if (!empty($authorization['error'])){
            return $this->json($authorization);
        }

        //Connect to the Database
        $person = $this->getDoctrine()->getRepository(Person::class)->find($person_id);


        if(!$person)
        {
            return $this->json([
                'error' => 'Error: No Person found for id '.$person_id,
                ]);
        }

        $events = $person->getEvent();
        $arrayCollection = array();

        foreach($events as $event)
        {
            $arrayCollection[$event->getId()] = $event->toArray();
        }

        return $this->json($arrayCollection);
    }

    /**
     * @Route("/api/event/{event_id}/people", name="api_geteventpeople")
     */
     public function getEventPeople(Request $request, int $event_id)
    {
        // Call the checkAuthorization method.
        $authorization = $this->checkAuthorization($request);

        // if token isn't excepted, this will give you an token error message
        if (!empty($authorization['error'])){
            return $this->json($authorization);
        }

        //Connect to the Database
        $event = $this->getDoctrine()->getRepository(Event::class)->find($event_id);


        if (!$event) {

            return $this->json([
                'error' => 'Error: No Event found for id '.$event_id,
                ]);
        }

        $people = $event->getPeople();
        $arrayCollection = array();

        foreach($people as $person)
        {
            $arrayCollection[$person->getId()] = $person->toArray();
        }

        return $this->json($arrayCollection);
    }
}
