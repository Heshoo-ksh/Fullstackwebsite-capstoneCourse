<?php

namespace App\Entity;

use App\Repository\PersonRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Security\Core\User\PasswordAuthenticatedUserInterface;
use Symfony\Component\Security\Core\User\UserInterface;

/**
 * @ORM\Entity(repositoryClass=PersonRepository::class)
 */
class Person implements UserInterface, PasswordAuthenticatedUserInterface
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=180, unique=true)
     */
    private $personEmail;

    /**
     * @ORM\Column(type="json")
     */
    private $roles = [];

    /**
     * @var string The hashed password
     * @ORM\Column(type="string")
     */
    private $password;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $personFirstName;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $personLastName;

    /**
     * @ORM\Column(type="string", length=255, nullable=true)
     */
    private $personPhoneNumber;

    /**
     * @ORM\ManyToMany(targetEntity=Event::class, inversedBy="people")
     */
    private $Event;

    public function __construct()
    {
        $this->Event = new ArrayCollection();
    }


    public function getId(): ?int
    {
        return $this->id;
    }

    public function getPersonEmail(): ?string
    {
        return $this->personEmail;
    }

    public function setPersonEmail(string $personEmail): self
    {
        $this->personEmail = $personEmail;

        return $this;
    }

    /**
     * A visual identifier that represents this user.
     *
     * @see UserInterface
     */
    public function getUserIdentifier(): string
    {
        return (string) $this->personEmail;
    }

    /**
     * @deprecated since Symfony 5.3, use getUserIdentifier instead
     */
    public function getUsername(): string
    {
        return (string) $this->personEmail;
    }

    /**
     * @see UserInterface
     */
    public function getRoles(): array
    {
        $roles = $this->roles;
        // guarantee every user at least has ROLE_USER
        $roles[] = 'ROLE_USER';

        return array_unique($roles);
    }

    /**
     * playing with arrays
     */
    public function toArray()
    {
        return[
            'id' => $this->id,
            'roles' => $this->roles,
            'personEmail' => $this->personEmail,
            'personFirstName' => $this->personFirstName,
            'personLastName' => $this->personLastName,
            'personPhoneNumber' => $this->personPhoneNumber
        ];
    }

    public function setRoles(array $roles): self
    {
        $this->roles = $roles;

        return $this;
    }

    /**
     * @see PasswordAuthenticatedUserInterface
     */
    public function getPassword(): string
    {
        return $this->password;
    }

    public function setPassword(string $password): self
    {
        $this->password = $password;

        return $this;
    }

    /**
     * Returning a salt is only needed, if you are not using a modern
     * hashing algorithm (e.g. bcrypt or sodium) in your security.yaml.
     *
     * @see UserInterface
     */
    public function getSalt(): ?string
    {
        return null;
    }

    /**
     * @see UserInterface
     */
    public function eraseCredentials()
    {
        // If you store any temporary, sensitive data on the user, clear it here
        // $this->plainPassword = null;
    }

    public function getPersonFirstName(): ?string
    {
        return $this->personFirstName;
    }

    public function setPersonFirstName(string $personFirstName): self
    {
        $this->personFirstName = $personFirstName;

        return $this;
    }

    public function getPersonLastName(): ?string
    {
        return $this->personLastName;
    }

    public function setPersonLastName(string $personLastName): self
    {
        $this->personLastName = $personLastName;

        return $this;
    }

    public function getPersonPhoneNumber(): ?string
    {
        return $this->personPhoneNumber;
    }

    public function setPersonPhoneNumber(?string $personPhoneNumber): self
    {
        $this->personPhoneNumber = $personPhoneNumber;

        return $this;
    }

    /**
     * @return Collection|Event[]
     */
    public function getEvent(): Collection
    {
        return $this->Event;
    }

    public function addEvent(Event $event): self
    {
        if (!$this->Event->contains($event)) {
            $this->Event[] = $event;
        }

        return $this;
    }

    public function removeEvent(Event $event): self
    {
        $this->Event->removeElement($event);

        return $this;
    }
}
